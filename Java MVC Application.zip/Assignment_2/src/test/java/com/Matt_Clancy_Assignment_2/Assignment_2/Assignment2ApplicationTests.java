package com.Matt_Clancy_Assignment_2.Assignment_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment2ApplicationTests {

	@Test
	void contextLoads() {



	}

}
