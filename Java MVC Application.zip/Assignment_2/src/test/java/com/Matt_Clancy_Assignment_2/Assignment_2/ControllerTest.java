package com.Matt_Clancy_Assignment_2.Assignment_2;

import static org.assertj.core.api.Assertions.assertThat;

import com.Matt_Clancy_Assignment_2.Assignment_2.controllers.UsersController;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ControllerTest {

    @Autowired
    private UsersController controller;

    @Test
    public void contextLoads() throws Exception {
        assertThat(controller).isNotNull();
    }
}