package com.Matt_Clancy_Assignment_2.Assignment_2.controllers;


import com.Matt_Clancy_Assignment_2.Assignment_2.CrudCommands.RegisterCrud;
import com.Matt_Clancy_Assignment_2.Assignment_2.models.Register;
import com.Matt_Clancy_Assignment_2.Assignment_2.models.Users;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class RegisterController {

    private RegisterCrud registerCrud;

    @RequestMapping("/Register")
    public String getRegister(){
        return "Register";
    }

    @RequestMapping("/")
    public String getRegister1(){
        return "Register";
    }

    @RequestMapping("/Index")
    public String getRegister2(){
        return "Register";
    }

    @GetMapping("/Register")
    public String RegisterForm(Model model) {
        model.addAttribute("Register", new Register());
        return "Register";
    }

    @PostMapping("/Register")
    public String registerSubmit(@ModelAttribute Register register, Model model) {
        model.addAttribute("Register", register);
        return "Success";
    }

    @RequestMapping("save")
    public String save(@ModelAttribute(value = "Register") Register register) {
        registerCrud.save(register);
        System.out.println("there are: " + registerCrud.count());
        return "saved";
    }

}


