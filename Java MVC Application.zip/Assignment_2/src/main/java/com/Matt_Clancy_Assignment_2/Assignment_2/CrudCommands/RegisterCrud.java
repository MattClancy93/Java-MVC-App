package com.Matt_Clancy_Assignment_2.Assignment_2.CrudCommands;


import com.Matt_Clancy_Assignment_2.Assignment_2.models.Register;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.Repository;

@org.springframework.stereotype.Repository
public interface RegisterCrud extends CrudRepository<Register, Long> {
}
