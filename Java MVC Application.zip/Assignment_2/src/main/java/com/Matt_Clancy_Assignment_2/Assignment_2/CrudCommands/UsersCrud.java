package com.Matt_Clancy_Assignment_2.Assignment_2.CrudCommands;

import com.Matt_Clancy_Assignment_2.Assignment_2.models.Users;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsersCrud extends CrudRepository<Users, Long> {


}