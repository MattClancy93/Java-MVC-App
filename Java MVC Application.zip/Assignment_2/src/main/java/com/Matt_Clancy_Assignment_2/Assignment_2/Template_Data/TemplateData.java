package com.Matt_Clancy_Assignment_2.Assignment_2.Template_Data;

import com.Matt_Clancy_Assignment_2.Assignment_2.CrudCommands.*;
import com.Matt_Clancy_Assignment_2.Assignment_2.models.Cart;
import com.Matt_Clancy_Assignment_2.Assignment_2.models.Products;
import com.Matt_Clancy_Assignment_2.Assignment_2.models.Users;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class TemplateData implements CommandLineRunner {

    private CartCrud cartCrud;
    private PaymentsCrud paymentsCrud;
    private UsersCrud usersCrud;
    private ProductsCrud productsCrud;
    

    public TemplateData(CartCrud cartCrud, PaymentsCrud paymentsCrud, UsersCrud usersCrud, ProductsCrud productsCrud) {
        this.cartCrud = cartCrud;
        this.paymentsCrud = paymentsCrud;
        this.usersCrud = usersCrud;
        this.productsCrud = productsCrud;
    }

    @Override
    public void run(String... args) throws Exception {



        Users a1 = new Users("matt0011", "Password1");
        Products p1 = new Products("Vegetable", "Carrot", "Small Carrot", "0.10");
        Products p2 = new Products("Vegetable", "Peas", "Tin of Peas", "0.25");
        Products p3 = new Products("Vegetable", "Pepper", "Red Pepper", "0.14");
        Products p4 = new Products("Fruit", "Tangerine", "Small Tangerine", "0.20");
        Products p5 = new Products("Candy", "Haribo", "500g pack of haribo", "1.00");
        Products p6 = new Products("Drink", "Pepsi", "1L pepsi", "0.99");



        usersCrud.save(a1);
        productsCrud.save(p1);
        productsCrud.save(p2);
        productsCrud.save(p3);
        productsCrud.save(p4);
        productsCrud.save(p5);
        productsCrud.save(p6);
        System.out.println("there are: " + productsCrud.count());

    }
}
