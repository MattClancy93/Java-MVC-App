package com.Matt_Clancy_Assignment_2.Assignment_2.controllers;

import com.Matt_Clancy_Assignment_2.Assignment_2.CrudCommands.CartCrud;
import com.Matt_Clancy_Assignment_2.Assignment_2.models.Cart;
import com.Matt_Clancy_Assignment_2.Assignment_2.models.Products;
import com.Matt_Clancy_Assignment_2.Assignment_2.models.Users;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CartController {

    private CartCrud cart;

    public Cart remove;


    public CartController(CartCrud cart) {
        this.cart = cart;
    }

    @RequestMapping("/Cart")
    public String getCart(Model model){
        model.addAttribute("cart", cart.findAll());
        return "cart";
    }


    public void addToCart(Products p)
    {
        Cart c = new Cart(p.getName(), p.getInformation(), p.getPrice());
        remove = c;
        cart.save(c);
    }
}
