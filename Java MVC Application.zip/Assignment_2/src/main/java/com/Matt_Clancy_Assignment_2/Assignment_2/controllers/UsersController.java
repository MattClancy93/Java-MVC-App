package com.Matt_Clancy_Assignment_2.Assignment_2.controllers;

import com.Matt_Clancy_Assignment_2.Assignment_2.CrudCommands.UsersCrud;
import com.Matt_Clancy_Assignment_2.Assignment_2.models.Users;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Objects;


@Controller
public class UsersController {

    private UsersCrud users;

    public UsersController(UsersCrud users) {
        this.users = users;
    }

    @GetMapping("/Users")
    public String registrationForm(Model model) {
        model.addAttribute("Users", new Users());
        return "Users";
    }

    @PostMapping("/Users")
    public String greetingSubmit(@ModelAttribute Users users, Model model) {
        model.addAttribute("Users", users);
        return "Success";
    }

    @PostMapping("/registerUser")
    public String registerUser(Users user)
    {
        users.save(user);

        return "Login";
    }

    @PostMapping("/loginUser")
    public String loginUser(Users user, HttpServletResponse response) {

        String a = user.getUsername();
        String b = user.getPassword();

        for (Users i : users.findAll()){
            String s = i.toString();
            System.out.println(s);
        }

        for (Users i : users.findAll()) {
            if (i.getUsername().equals(a) && i.getPassword().equals(b)) {
                try {
                    response.sendRedirect("/HomePage");
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
            else {
                continue;
            }
        }
        return "Login";
    }

    @PostMapping("/logout")
    public void logout(HttpServletResponse response) {
                try {
                    response.sendRedirect("/Login");
                } catch (IOException e) {
                    e.printStackTrace();
                }
    }






}
