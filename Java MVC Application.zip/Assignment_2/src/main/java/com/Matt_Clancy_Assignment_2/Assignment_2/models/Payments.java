package com.Matt_Clancy_Assignment_2.Assignment_2.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Objects;

@Entity
public class Payments {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long ID;

    private String userLoggedIn;
    private Boolean paymentAccepted;

    public Payments() {
    }

    public Payments(String userLoggedIn, Boolean paymentAccepted) {
        this.userLoggedIn = userLoggedIn;
        this.paymentAccepted = paymentAccepted;
    }

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    public String getUserLoggedIn() {
        return userLoggedIn;
    }

    public void setUserLoggedIn(String userLoggedIn) {
        this.userLoggedIn = userLoggedIn;
    }

    public Boolean getPaymentAccepted() {
        return paymentAccepted;
    }

    public void setPaymentAccepted(Boolean paymentAccepted) {
        this.paymentAccepted = paymentAccepted;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Payments payments = (Payments) o;

        return Objects.equals(ID, payments.ID);
    }

    @Override
    public int hashCode() {
        return ID != null ? ID.hashCode() : 0;
    }
}
