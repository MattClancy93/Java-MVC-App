package com.Matt_Clancy_Assignment_2.Assignment_2.controllers;


import com.Matt_Clancy_Assignment_2.Assignment_2.CrudCommands.UsersCrud;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {

    @RequestMapping("/Login")
    public String getLogin(){
        return "Login";
    }

}
