package com.Matt_Clancy_Assignment_2.Assignment_2.controllers;

import com.Matt_Clancy_Assignment_2.Assignment_2.CrudCommands.ProductsCrud;
import com.Matt_Clancy_Assignment_2.Assignment_2.models.Products;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Controller
public class ProductsController {

    private ProductsCrud products;
    private final CartController c1;
    public Products p1;

    public ProductsController(ProductsCrud products, CartController c1){
        this.products = products;
        this.c1 = c1;
    }

    @RequestMapping("/HomePage")
    public String getProducts(Model model){
        model.addAttribute("HomePage", products.findAll());
        System.out.println(products.count());
        return "HomePage";
    }

    @PostMapping("/search")
    public String searchProducts(Products product, Model model){
        String search = product.getName();

        System.out.println(search);
        for (Products i : products.findAll()){

            if (i.getName().equals(search)){
                returnProducts(i, model);
                p1 = i;
            }
            else {
                continue;
            }

        }

        return "HomePage";
    }

    public String returnProducts(Products p, Model model){

        model.addAttribute("HomePage", p);
        return "HomePage";

    }

    @PostMapping("/addItem")
    public void addToBasket(HttpServletResponse hsr){

        System.out.println(p1.toString());

        c1.addToCart(p1);
        try {
            hsr.sendRedirect("HomePage");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }






}
